// import * as firebase from 'firebase';

// // Initialize Firebase
// var config = {
// 	 apiKey: "AIzaSyBZI4fIE6ngNTkLxXgTmVY8Z61j4It79FM",
// 	 authDomain: "hackathon-535b6.firebaseapp.com",
// 	 databaseURL: "https://hackathon-535b6.firebaseio.com",
// 	 projectId: "hackathon-535b6",
// 	 storageBucket: "hackathon-535b6.appspot.com",
// 	 messagingSenderId: "170757033325"
// };


// firebase.initializeApp(config);
